from django.shortcuts import redirect, render
from django.contrib.auth import get_user_model
from django.contrib.auth import authenticate, login, logout
from public.models import  Grievance

User =get_user_model()
# Create your views here.

def getGrvnc(request):

    user = request.user
    grvnc = Grievance.objects.filter(dept = user.dept)

    usr = User.objects.filter(hod=False, admin=False)

    
    # usrs = User.objects.filter(is_subAdmin = True)
    # u = usrs.first()
    # dpts = Departments.objects.filter(uid = u.id)
    # d = dpts.last()

    # grvs = Grievance.objects.filter(d_id = d.id)
    context = zip(grvnc, usr)
    

    return render(request, 'manageGrc.html', {'grvs':grvnc, 'context':context})

def acptGrv(request, uuid):
    grv = Grievance.objects.get(id = uuid)
    
    if grv.status == "P" :

        grv.status = "PR"

        grv.save()

    # print(grv.status)
    return redirect('pwddep')

def gintGrv(request, uuid):
    gvn = Grievance.objects.get(id = uuid)
    
    if gvn.status == "PR" :

        gvn.status = "C"

        gvn.save()

    # print(gvn.status)
    return redirect('pwddep')

def view_profile(request):

    return render(request, 'pwProfile.html')


def pagelogout(request):
    logout(request)

    return redirect('index')