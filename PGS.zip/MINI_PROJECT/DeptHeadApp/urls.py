from django.urls import path
from . import views

urlpatterns = [
    path('viewGrvnc/', views.getGrvnc, name='view_grv'),
    path('acptGrvnc/<uuid>/', views.acptGrv, name='acpt_grv'),
    path('fnshGrvnc/<uuid>/', views.gintGrv, name='fnsh_grv'),
    path('viewProfile/', views.view_profile, name='view_profile'),

    path('logout/', views.pagelogout, name = 'logout')
]