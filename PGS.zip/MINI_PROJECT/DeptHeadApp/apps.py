from django.apps import AppConfig


class DeptheadappConfig(AppConfig):
    name = 'DeptHeadApp'
