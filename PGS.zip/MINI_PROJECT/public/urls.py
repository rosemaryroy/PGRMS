from django.urls import path
from . import views

urlpatterns = [
    path('register/',views.registerGrievance, name='reg_grievance'),
    path('prev/', views.ComplaintPrev, name='prev'),
    path('chk_sts/', views.checkStatus, name = 'chk_sts'),
    path('feedback/', views.setFeedback, name = 'feedback'),
    path('reopen/', views.reopenGrievance, name = 'reopen'),
    path('reopen/action/', views.reopenAction, name = 'reopen_action'),
    path('view_profile/', views.viewProfile, name = 'profile'),
    
]