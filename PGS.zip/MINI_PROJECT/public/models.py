import uuid
from django.db import models
from AdminApp.models import ComplaintType, Departments
from django.conf import settings
User = settings.AUTH_USER_MODEL
# Create your models here.

# class Login(models.Model):
#     pwd = models.CharField(max_length=10)
#     email = models.CharField(max_length=20)
#     utype = models.CharField(max_length=20)

# class register(models.Model):
#     name = models.CharField(max_length=20)
#     telephone = models.CharField(max_length=10)
#     email = models.EmailField(max_length=20)
#     password = models.CharField(max_length=10)

'''
    > Class name must be start with CAPS
    > After creating a model class you have to register model with site using admin
'''

class Grievance(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    description = models.TextField()
    field_name = models.FileField(upload_to='files', null=True, blank=True)
    # name = models.CharField(max_length=20)
    # CHOICES = [('M','Male'),('F','Female')]
    # Gender = models.CharField(choices=CHOICES,max_length=128)
    # house_no = models.CharField(max_length=10)
    # house_name = models.CharField(max_length=20)
    # street_name = models.CharField(max_length=20)
    # phone_no = models.IntegerField(max_length=10)
    # email = models.EmailField(max_length=20)
    dept = models.ForeignKey(Departments, on_delete=models.CASCADE,default="", null=True)
    cplType = models.ForeignKey(ComplaintType, on_delete=models.CASCADE, default="", null=True)
    S_CHOICES = [('P','Pending'),('PR','Processing'),('C','Complete')]
    user_id = models.OneToOneField(User, on_delete=models.CASCADE,)
    status = models.CharField(max_length=2, choices=S_CHOICES, default='P')

    

class Feedback(models.Model):
    # name = models.CharField(max_length=20)
    # phone = models.IntegerField(max_length=10)
    description = models.CharField(max_length=100)

    