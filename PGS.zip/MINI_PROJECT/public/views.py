from django.core.checks import messages
from django.shortcuts import redirect, render
from django.template import loader
from django.http import HttpResponse, request 
from django.contrib.auth.models import User
from django.contrib import sessions
from AdminApp.models import Departments, ComplaintType
from .models import Grievance
from .forms import FeedBackForm, GrievanceForm
from django.contrib.auth import get_user_model

User = get_user_model()

# Create your views here.
def registerGrievance(request):
  print('cu', request.user)
  cUser = request.user
  msg = None
  dpts = Departments.objects.all()
  cTypes = ComplaintType.objects.all()
  # print(grvnc.id)
  if request.method == 'POST':

    form = GrievanceForm(request.POST)
    b = form
    # print(b.user_id)
    if form.is_valid():
      grs = form.save(commit=False)

      # grs.user_id = form.cleaned_data.get('fname')
      # grs.gender = form.cleaned_data.get('select_gender')
      # grs.house_no = form.cleaned_data.get('hnumber')
      # grs.house_name = form.cleaned_data.get('hname')
      # grs.street_name = form.cleaned_data.get('streetname')
      # grs.phone_no = form.cleaned_data.get('PHONE')
      # grs.email = form.cleaned_data.get('EMAIL')
      # grs.dept = form.cleaned_data.get('dept')
      # grs.cplType = form.cleaned_data.get('ctype')

      grs.user_id = request.user
      grs.cplType = form.cleaned_data.get('value')
      grs.save()
      msg = 'Successfully Submitted'
      print( msg )
      return redirect('prev')

    else:

      msg = 'Form is not valid'
      # print('error', form.errors)

  else:

    form = GrievanceForm()
  
  return render(request, 'form.html', {'form': form, 'dpts': dpts, 'cTypes': cTypes, 'msg': msg})

def ComplaintPrev(request):

  user = request.user.id

  print(user)

  grvnc = Grievance.objects.get(user_id = user)
  print('grv', grvnc)

  #fdf24951-2265-4c15-9f35-86cb64865feb

  return render(request, 'pre.html', {'grv':grvnc})


def checkStatus(request):
    grvn = None
    msg = None
    data = request.POST.get('token')

    if not data:
      grvn = None
    else:
      grvn = Grievance.objects.get(id = data)

      if grvn.status == "P":

        msg = "Pending"

      elif grvn.status == "PR":

        msg = "Processing"

      else:

        msg = "Success"

    return render(request, 'viewStatus.html', {'msg': msg})


# b69e8ac2-3e4f-43df-96a5-4a7d7ad6fd92


def setFeedback(request):
  msg = None

  if request.method == 'POST':

    form = FeedBackForm(request.POST)

    if form.is_valid():

      fb = form.save()
      
      msg = 'Successfully Submitted'
      print( msg )
      # return redirect('prev')
    
    else:

      msg = "Form is not valid"

  else:

    form = FeedBackForm()
  return render(request, 'feedback.html', {'form':form ,'msg':msg})


def reopenGrievance(request):
  user = request.user.id
  allGrv = Grievance.objects.filter(user_id = user)

  return render(request, 'reopen.html', {'grvn':allGrv})

def reopenAction(request, uuid):

  grv = Grievance.objects.get(id = uuid)
    
  if grv.status == "C" :

      grv.status = "P"

      grv.save()

  # print(grv.status)
  return redirect('reopen')



def viewProfile(request):

  return render(request, 'profile.html')