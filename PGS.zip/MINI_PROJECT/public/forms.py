from django import forms
from django.db.models import fields
from .models import Grievance, Feedback

class GrievanceForm(forms.ModelForm):

        description = forms.CharField(widget=forms.Textarea)
        
        

        
        class Meta:
            model = Grievance
            fields = ('description', 'dept',)

class FeedBackForm(forms.ModelForm):

    description = forms.CharField(widget=forms.Textarea)

    name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}))
    phone = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}))

    class Meta:
        model = Feedback
        fields = ('description', 'name', 'phone')