from django.urls import path
from . import views

urlpatterns = [

    path('add_head/', views.addHead, name='add_head'),
    path('view_hod/', views.ViewHeads, name='view_heads'),
    path('view_user/', views.ViewUser, name='view_users'),
]