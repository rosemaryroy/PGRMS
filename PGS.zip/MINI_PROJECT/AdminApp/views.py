from django.http import request
from django.shortcuts import render, redirect
from .forms import HodForm
from .models import Departments
from django.contrib.auth import get_user_model

User = get_user_model()


def addHead(request):
    
    print(request.user.dept)
    msg = None
    depts = Departments.objects.all()

    if request.method == 'POST':

        form = HodForm(request.POST)
        # print('frm', form)
        if form.is_valid():
            ah = form.save(commit=False)
            ah.dept = form.cleaned_data.get('value')
            ah.save()
            msg = "Successfully Created"

            return redirect('admin')
        else:
            msg = "Form is not valid"
            print('err', form.errors)
    else:

        form = HodForm()
    
    return render(request, 'hod.html', {'form': form, 'msg':msg, 'dpts':depts})



def ViewHeads(request):

    dpHeads = User.objects.filter(hod = True)

    print('dp', dpHeads)

    return render(request, 'viewHod.html', {'dpHeads':dpHeads})




    # # dpts = None
    # hods = None
    # dps = []

    # for user in User.objects.filter(is_subAdmin = True):
        
    #     # print(user.id)
    #     dpts = Departments.objects.filter(uid = user.id)
        
    #     dps.append(dpts)
    #     # print(dpts)
    
    # hods = User.objects.filter(is_subAdmin =True)
     
    # context = zip(hods, dps)

    # # print('hod', hods)
    # print('hod', dps)
    # # print('hod', hod.dept_name)


def ViewUser(request):

    users = User.objects.filter(hod = False, admin = False)
    print(users)
    return render(request, 'viewUser.html', {'users':users})


