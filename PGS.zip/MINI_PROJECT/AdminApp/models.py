import uuid
from django.db import models



# from django.conf import settings
# User = settings.AUTH_USER_MODEL



# Create your models here.

class Departments(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    # uid = models.ForeignKey(User, on_delete=models.CASCADE)
    dept_name = models.CharField(max_length=20)

    def __str__(self):
        return self.dept_name

class ComplaintType(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    dept = models.ForeignKey(Departments,related_name='department', on_delete=models.CASCADE)
    type = models.CharField(max_length=500, blank=True)