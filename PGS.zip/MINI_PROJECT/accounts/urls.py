from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('login/', views.login_view, name='login_view'),
    path('register/', views.register, name='register'),
    path('adminPage/', views.admin, name='admin'),
    path('subAdmin/', views.sub_admin, name='sub_admin'),
    path('public/', views.user, name='public'),


    # Department views

    path('departments/pwd/', views.pwddep, name='pwddep'),
    path('departments/construction/', views.construction, name='construction'),
]