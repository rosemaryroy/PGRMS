from django.http import request
from django.shortcuts import render, redirect
from .forms import LoginForm, SignUpForm
from AdminApp.models import Departments
from django.contrib.auth import authenticate, login

# Create your views here.

msg = None

def index(request):
    dpts = Departments.objects.all()
    return render(request, 'index.html', {'dpts': dpts})

def register(request):
    msg = None

    if request.method == 'POST':

        form = SignUpForm(request.POST)
    

        if form.is_valid():

            user = form.save()
            msg = 'User Created'

            return redirect('login_view')
        
        else:

            msg = 'Form is not valid'
    
    else:

        form = SignUpForm()

    return render(request, 'register.html', {'form': form, 'msg':msg})

def login_view(request):

    form = LoginForm(request.POST or None)
    msg = None

    if request.method == 'POST':
        if form.is_valid():
            username = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')

            print('un', username)
            print('pw', password)

            user = authenticate(username=username, password=password)

            if user is not None and user.is_admin:

                login(request, user)
                return redirect('admin')
            
            elif user is not None and user.is_staff:
                
                dpt = user.dept
                
                if str(dpt) == "PWD":
                    login(request, user)
                    return redirect('pwddep')
                
                elif str(dpt) == "Construction":
                      login(request, user)
                      return redirect('construction')                    
                else:

                    return redirect(request, 'login_view')

            elif user is not None and not user.is_staff and not user.is_admin:

                login(request, user)
                return redirect('public')

            else:

                msg = 'Invalid Credentials'
        
        else:

            msg = 'Error validating form'
    
    return render(request, 'login.html', {'form': form, 'msg': msg})


def admin(request):
    return render(request, 'admin.html')

def sub_admin(request):
    return render(request, 'hodHome.html')

def pwddep(request):
    return render(request, 'pwddep.html')

def construction(request):
    return render(request, 'cons.html')

def user(request):
    msg = request.session.get('msg', False)
    return render(request, 'public.html', {'message': msg})


